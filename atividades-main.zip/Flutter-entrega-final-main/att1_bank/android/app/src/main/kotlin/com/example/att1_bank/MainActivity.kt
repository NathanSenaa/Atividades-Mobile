package com.example.att1_bank

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
