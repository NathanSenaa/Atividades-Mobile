class MoedaRepository {
  static List<Moeda> tabela [
    Moeda(
          icone: 'a', 
          nome: 'BitCoin', 
          sigla: 'btc', 
          preco: 143.131),
  ];
}