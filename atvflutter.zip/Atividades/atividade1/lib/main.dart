import 'package:atividade1/meu_aplicativo.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(const MeuAplicativo());
}
