package com.example.att2_bank

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
