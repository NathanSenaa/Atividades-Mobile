class Cliente {
  String nome;
  double saldo;

  Cliente({required this.nome, required this.saldo});
}
